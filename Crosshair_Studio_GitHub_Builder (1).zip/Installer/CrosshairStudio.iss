; Crosshair Studio one-click Windows installer
#define AppName "Crosshair Studio"
#define AppVersion "1.0.0"
#define AppExeName "Crosshair Studio.exe"

[Setup]
AppId={{A6B1B58E-9D7C-4A54-BB5C-5B4F9F1A0D31}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\Crosshair Studio
DefaultGroupName=Crosshair Studio
OutputDir=installer
OutputBaseFilename=Crosshair-Studio-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\{#AppExeName}

[Files]
Source: "..\CrosshairStudio\bin\Release\Crosshair Studio.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Crosshair Studio"; Filename: "{app}\{#AppExeName}"
Name: "{autodesktop}\Crosshair Studio"; Filename: "{app}\{#AppExeName}"

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch Crosshair Studio"; Flags: nowait postinstall skipifsilent
