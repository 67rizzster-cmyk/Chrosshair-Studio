
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace CrosshairStudio {
    public class Crosshair {
        public string Name;
        public Color Color;
        public int Length, Thickness, Gap, Dot, Outline;
        public int Id;
        public Crosshair Clone() { return (Crosshair)MemberwiseClone(); }
    }

    public class MainForm : Form {
        const int HOTKEY_ID = 9001;
        const int WM_HOTKEY = 0x0312;
        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
        static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        const uint SWP_NOSIZE=0x0001, SWP_NOMOVE=0x0002, SWP_NOACTIVATE=0x0010, SWP_SHOWWINDOW=0x0040;

        List<Crosshair> presets = new List<Crosshair>();
        HashSet<int> favorites = new HashSet<int>();
        Crosshair current;
        OverlayForm overlay;
        NotifyIcon tray;
        Panel preview;
        ListBox library;
        TextBox search;
        TrackBar length, thickness, gap, dot, outline;
        Button colorBtn, saveBtn, stopBtn;
        bool overlayRunning=false;

        Color[] colors = { Color.White, Color.Lime, Color.Cyan, Color.HotPink, Color.Yellow, Color.MediumPurple, Color.Orange, Color.Chartreuse };
        string[] names = { "Pulse","Nova","Zero","Phantom","Rift","Clean","Vortex","Beam" };

        public MainForm() {
            Text = "Crosshair Studio";
            Size = new Size(1120,720);
            MinimumSize = new Size(900,600);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(12,15,21);
            ForeColor = Color.White;
            Font = new Font("Segoe UI Variable", 9);
            GeneratePresets();
            BuildUI();
            current = presets[0].Clone();
            LoadCurrent();
            overlay = new OverlayForm(() => current);
            tray = new NotifyIcon();
            tray.Icon = SystemIcons.Application;
            tray.Text = "Crosshair Studio";
            tray.Visible = true;
            var menu = new ContextMenuStrip();
            menu.Items.Add("Show editor", null, (s,e)=>ShowEditor());
            menu.Items.Add("Hide editor", null, (s,e)=>HideEditor());
            menu.Items.Add("Stop crosshair", null, (s,e)=>StopOverlay());
            menu.Items.Add("Exit", null, (s,e)=>CloseAll());
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += (s,e)=>ShowEditor();
            RegisterHotKey(Handle, HOTKEY_ID, 0, (uint)Keys.F8);
        }

        void GeneratePresets() {
            for(int i=1;i<=1000;i++) {
                var c = new Crosshair {
                    Id=i,
                    Name=names[i%names.Length]+" "+i.ToString("000"),
                    Color=colors[i%colors.Length],
                    Length=5+(i*17)%31,
                    Thickness=1+(i*7)%6,
                    Gap=(i*13)%18,
                    Dot=(i%9==0 ? 2+(i%8) : 0),
                    Outline=(i%7==0 ? 1 : 0)
                };
                presets.Add(c);
            }
        }

        Label Label(string text, int x, int y, int w=250) {
            var l=new Label {Text=text, Location=new Point(x,y), Size=new Size(w,22), ForeColor=Color.FromArgb(155,165,185)};
            Controls.Add(l); return l;
        }

        TrackBar Slider(string title, int y, int min, int max, int value, Action<int> changed) {
            Label(title, 750,y,280);
            var t=new TrackBar {Minimum=min,Maximum=max,Value=value,Location=new Point(750,y+20),Width=300,TickStyle=TickStyle.None};
            t.Scroll += (s,e)=>changed(t.Value);
            Controls.Add(t); return t;
        }

        void BuildUI() {
            var title=new Label {Text="✦ CROSSHAIR STUDIO",Font=new Font("Segoe UI Variable Display",20,FontStyle.Bold),Location=new Point(20,15),Size=new Size(450,38)};
            Controls.Add(title);
            var sub=new Label {Text="1,000 presets  •  custom toolbox  •  background overlay",ForeColor=Color.FromArgb(135,145,165),Location=new Point(22,53),AutoSize=true};
            Controls.Add(sub);

            search=new TextBox {Location=new Point(20,90),Width=290,Height=30,BackColor=Color.FromArgb(24,29,39),ForeColor=Color.White};
            search.TextChanged += (s,e)=>RefreshLibrary();
            Controls.Add(search);

            library=new ListBox {Location=new Point(20,130),Size=new Size(290,510),BackColor=Color.FromArgb(16,20,28),ForeColor=Color.White,BorderStyle=BorderStyle.FixedSingle,DrawMode=DrawMode.OwnerDrawFixed,ItemHeight=42};
            library.DrawItem += DrawLibraryItem;
            library.SelectedIndexChanged += (s,e)=>{ if(library.SelectedIndex>=0){current=Filtered()[library.SelectedIndex].Clone();LoadCurrent();} };
            Controls.Add(library);

            preview=new Panel {Location=new Point(330,90),Size=new Size(390,550),BackColor=Color.FromArgb(7,9,13)};
            preview.Paint += (s,e)=>DrawCrosshair(e.Graphics, preview.ClientSize.Width/2, preview.ClientSize.Height/2, current);
            Controls.Add(preview);

            Label("TOOLBOX",750,90,300);
            length=Slider("Length",125,1,80,12,v=>{current.Length=v;preview.Invalidate();});
            thickness=Slider("Thickness",195,1,15,3,v=>{current.Thickness=v;preview.Invalidate();});
            gap=Slider("Gap",265,0,35,5,v=>{current.Gap=v;preview.Invalidate();});
            dot=Slider("Center dot",335,0,20,0,v=>{current.Dot=v;preview.Invalidate();});
            outline=Slider("Outline",405,0,6,0,v=>{current.Outline=v;preview.Invalidate();});

            colorBtn=new Button {Text="Choose color",Location=new Point(750,485),Size=new Size(130,38)};
            colorBtn.Click += (s,e)=>ChooseColor();
            Controls.Add(colorBtn);

            saveBtn=new Button {Text="SAVE & RUN IN BACKGROUND",Location=new Point(750,535),Size=new Size(300,42),BackColor=Color.FromArgb(109,93,252),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};
            saveBtn.Click += (s,e)=>StartOverlay();
            Controls.Add(saveBtn);

            stopBtn=new Button {Text="Stop overlay",Location=new Point(890,485),Size=new Size(160,38),Visible=false};
            stopBtn.Click += (s,e)=>StopOverlay();
            Controls.Add(stopBtn);

            var imp=new Button {Text="Import JSON / image",Location=new Point(20,650),Size=new Size(150,30)};
            imp.Click += (s,e)=>Import();
            Controls.Add(imp);

            var exp=new Button {Text="Export preset",Location=new Point(180,650),Size=new Size(130,30)};
            exp.Click += (s,e)=>Export();
            Controls.Add(exp);

            RefreshLibrary();
        }

        List<Crosshair> Filtered() {
            string q=search==null ? "" : search.Text.ToLower();
            var list=new List<Crosshair>();
            foreach(var p in presets) if(q=="" || p.Name.ToLower().Contains(q) || p.Id.ToString().Contains(q)) list.Add(p);
            return list;
        }

        void RefreshLibrary() {
            if(library==null)return;
            var list=Filtered(); library.BeginUpdate(); library.Items.Clear();
            foreach(var p in list) library.Items.Add((p.Id%9==0?"★ ":"")+p.Name);
            library.EndUpdate();
        }

        void DrawLibraryItem(object sender, DrawItemEventArgs e) {
            if (e.Index < 0) return;
            var list = Filtered();
            if (e.Index >= list.Count) return;
            var p = list[e.Index];

            e.DrawBackground();
            using (var textBrush = new SolidBrush(Color.White))
                e.Graphics.DrawString((p.Id % 9 == 0 ? "★ " : "") + p.Name,
                    new Font("Segoe UI Variable", 9), textBrush, new PointF(10, 12));

            // Small visual reference on the right side of each preset name.
            int cx = e.Bounds.Right - 27, cy = e.Bounds.Top + 21;
            using (var outline = new Pen(Color.FromArgb(20,20,20), Math.Max(1, p.Thickness + p.Outline * 2)))
                DrawLines(e.Graphics, outline, p, cx, cy);
            using (var pen = new Pen(p.Color, Math.Max(1, p.Thickness)))
                DrawLines(e.Graphics, pen, p, cx, cy);
            if (p.Dot > 0)
                using (var b = new SolidBrush(p.Color)) {
                    float d = Math.Min(8, p.Dot);
                    e.Graphics.FillEllipse(b, cx-d/2f, cy-d/2f, d, d);
                }

            e.DrawFocusRectangle();
        }

        void LoadCurrent() {
            length.Value=Math.Max(length.Minimum,Math.Min(length.Maximum,current.Length));
            thickness.Value=Math.Max(thickness.Minimum,Math.Min(thickness.Maximum,current.Thickness));
            gap.Value=Math.Max(gap.Minimum,Math.Min(gap.Maximum,current.Gap));
            dot.Value=Math.Max(dot.Minimum,Math.Min(dot.Maximum,current.Dot));
            outline.Value=Math.Max(outline.Minimum,Math.Min(outline.Maximum,current.Outline));
            colorBtn.BackColor=current.Color;
            preview.Invalidate();
            if(overlay!=null)overlay.Invalidate();
        }

        void ChooseColor() {
            using(var d=new ColorDialog()) {
                d.Color=current.Color;
                if(d.ShowDialog()==DialogResult.OK){current.Color=d.Color;colorBtn.BackColor=d.Color;preview.Invalidate();overlay.Invalidate();}
            }
        }

        void DrawCrosshair(Graphics g,int cx,int cy,Crosshair c) {
            g.SmoothingMode=SmoothingMode.AntiAlias;
            if(c.Outline>0) {
                using(var p=new Pen(Color.Black,c.Thickness+c.Outline*2)) DrawLines(g,p,c,cx,cy);
            }
            using(var p=new Pen(c.Color,c.Thickness)) DrawLines(g,p,c,cx,cy);
            if(c.Dot>0) using(var b=new SolidBrush(c.Color)) {
                float d=c.Dot;g.FillEllipse(b,cx-d/2f,cy-d/2f,d,d);
            }
        }

        void DrawLines(Graphics g,Pen p,Crosshair c,int x,int y) {
            g.DrawLine(p,x,y-c.Gap,x,y-c.Gap-c.Length);
            g.DrawLine(p,x,y+c.Gap,x,y+c.Gap+c.Length);
            g.DrawLine(p,x-c.Gap,y,x-c.Gap-c.Length,y);
            g.DrawLine(p,x+c.Gap,y,x+c.Gap+c.Length,y);
        }

        void StartOverlay() {
            overlayRunning=true;
            overlay.Show();
            SetWindowPos(overlay.Handle,HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
            HideEditor();
            stopBtn.Visible=true;
        }
        void StopOverlay() {
            overlayRunning=false;
            overlay.Hide();
            ShowEditor();
            stopBtn.Visible=false;
        }
        void ShowEditor(){ if(search!=null && search.Text=="tool") search.Clear(); Show();WindowState=FormWindowState.Normal;Activate();}
        void HideEditor(){Hide();}
        void CloseAll(){tray.Visible=false;overlay.Close();UnregisterHotKey(Handle,HOTKEY_ID);Close();}

        void Import() {
            using(var d=new OpenFileDialog()){d.Filter="Crosshair JSON or Image|*.json;*.png;*.jpg;*.jpeg|All files|*.*";
                if(d.ShowDialog()!=DialogResult.OK)return;
                if(Path.GetExtension(d.FileName).ToLower()==".json"){
                    string s=File.ReadAllText(d.FileName);
                    current.Name=Match(s,"Name",current.Name);
                    current.Length=IntMatch(s,"Length",current.Length);
                    current.Thickness=IntMatch(s,"Thickness",current.Thickness);
                    current.Gap=IntMatch(s,"Gap",current.Gap);
                    current.Dot=IntMatch(s,"Dot",current.Dot);
                    current.Outline=IntMatch(s,"Outline",current.Outline);
                    LoadCurrent();
                } else MessageBox.Show("Image imported as a visual reference. Use the toolbox to recreate it.","Crosshair Studio");
            }
        }
        string Match(string s,string key,string def){var m=Regex.Match(s,"\""+key+"\"\\s*:\\s*\"([^\"]+)\"");return m.Success?m.Groups[1].Value:def;}
        int IntMatch(string s,string key,int def){var m=Regex.Match(s,"\""+key+"\"\\s*:\\s*(\\d+)");int v;return m.Success&&int.TryParse(m.Groups[1].Value,out v)?v:def;}
        void Export() {
            using(var d=new SaveFileDialog()){d.Filter="JSON preset|*.json";d.FileName=(current.Name??"crosshair")+".json";
                if(d.ShowDialog()!=DialogResult.OK)return;
                string hex=ColorTranslator.ToHtml(current.Color);
                File.WriteAllText(d.FileName,"{\\n  \"Name\":\""+current.Name.Replace("\"","")+"\",\\n  \"Length\":"+current.Length+",\\n  \"Thickness\":"+current.Thickness+",\\n  \"Gap\":"+current.Gap+",\\n  \"Dot\":"+current.Dot+",\\n  \"Outline\":"+current.Outline+",\\n  \"Color\":\""+hex+"\"\\n}");
            }
        }

        protected override void WndProc(ref Message m) {
            if(m.Msg==WM_HOTKEY && m.WParam.ToInt32()==HOTKEY_ID) {
                if(Visible) HideEditor(); else ShowEditor();
            }
            base.WndProc(ref m);
        }
        protected override void OnFormClosing(FormClosingEventArgs e) {
            if(e.CloseReason==CloseReason.UserClosing && overlayRunning){e.Cancel=true;HideEditor();return;}
            base.OnFormClosing(e);
        }

        class OverlayForm:Form {
            Func<Crosshair> getter;
            [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr hWnd,int nIndex);
            [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hWnd,int nIndex,int dwNewLong);
            public OverlayForm(Func<Crosshair> g){getter=g;FormBorderStyle=FormBorderStyle.None;WindowState=FormWindowState.Maximized;TopMost=true;ShowInTaskbar=false;BackColor=Color.Magenta;TransparencyKey=Color.Magenta;DoubleBuffered=true;}
            protected override void OnShown(EventArgs e){base.OnShown(e);int ex=GetWindowLong(Handle,-20);SetWindowLong(Handle,-20,ex|0x20|0x80);}
            protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var c=getter();Draw(e.Graphics,Width/2,Height/2,c);}
            void Draw(Graphics g,int cx,int cy,Crosshair c){g.SmoothingMode=SmoothingMode.AntiAlias;
                if(c.Outline>0)using(var p=new Pen(Color.Black,c.Thickness+c.Outline*2)){Lines(g,p,c,cx,cy);}
                using(var p=new Pen(c.Color,c.Thickness)){Lines(g,p,c,cx,cy);}
                if(c.Dot>0)using(var b=new SolidBrush(c.Color)){float d=c.Dot;g.FillEllipse(b,cx-d/2f,cy-d/2f,d,d);}
            }
            void Lines(Graphics g,Pen p,Crosshair c,int x,int y){g.DrawLine(p,x,y-c.Gap,x,y-c.Gap-c.Length);g.DrawLine(p,x,y+c.Gap,x,y+c.Gap+c.Length);g.DrawLine(p,x-c.Gap,y,x-c.Gap-c.Length,y);g.DrawLine(p,x+c.Gap,y,x+c.Gap+c.Length,y);}
        }
    }

    static class Program {
        [STAThread] static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MainForm());}
    }
}
